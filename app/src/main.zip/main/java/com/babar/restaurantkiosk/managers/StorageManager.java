package com.babar.restaurantkiosk.managers;

import android.content.Context;

import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;

/***********************************
 * Created by Babar on 12/12/2020.  *
 ***********************************/
public class StorageManager {
    private static StorageManager ourInstance;
    private FirebaseStorage firebaseStorage;
    private Context context;
    private static final String ROOT_REF = "admobi";

    public static StorageManager getInstance(Context context) {
        if(ourInstance==null) {
            ourInstance = new StorageManager(context);
        }
        return ourInstance;
    }

    private StorageManager(Context context) {
        this.context = context;
        this.firebaseStorage = FirebaseStorage.getInstance();
    }

    public Task<ListResult> getFolders(){
        return firebaseStorage.getReference(ROOT_REF).listAll();
    }

    public Task<ListResult> getFiles(String path){
        return firebaseStorage.getReference(ROOT_REF).child(path).listAll();
    }
}
