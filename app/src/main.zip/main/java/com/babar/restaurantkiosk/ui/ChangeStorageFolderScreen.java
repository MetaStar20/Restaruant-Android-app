package com.babar.restaurantkiosk.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.os.Bundle;
import android.view.View;

import com.babar.restaurantkiosk.R;
import com.babar.restaurantkiosk.adapters.StorageFolderRecyclerViewAdapter;
import com.babar.restaurantkiosk.managers.MyFDBManager;
import com.babar.restaurantkiosk.managers.MyWorkerManager;
import com.babar.restaurantkiosk.managers.StorageManager;
import com.babar.restaurantkiosk.models.UserInfoModel;
import com.babar.restaurantkiosk.util.DebugLog;
import com.babar.restaurantkiosk.util.LocalCache;
import com.babar.restaurantkiosk.util.RKUtil;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class ChangeStorageFolderScreen extends AppCompatActivity {
    List<String> folders = new ArrayList<>();
    RecyclerView recyclerView;
    private int checkBoxPosition = -1;
    StorageFolderRecyclerViewAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage_folder_screen);
        recyclerView = findViewById(R.id.folderRV);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                layoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);

      /*  StorageFolderRecyclerViewAdapter adapter = new StorageFolderRecyclerViewAdapter(folders, new StorageFolderRecyclerViewAdapter.CheckBoxListener() {
            @Override
            public void onChecked(int position) {

            }
        });
        recyclerView.setAdapter(adapter);*/
        listAllFolders();

    }


    public void closeFolder(View v){
        finish();
    }
    public void saveFolder(View v){
        if(checkBoxPosition!=-1){
            DebugLog.console("[ChangeStorageFolderScreen] inside saveFolder() -1");
            LocalCache.setStorageFolder(folders.get(checkBoxPosition));
            String deviceId = RKUtil.getDeviceId(this);
            DebugLog.console("[SettingScreen] inside onCreate() deviceId : " + deviceId);
            UserInfoModel userInfoModel = new UserInfoModel(LocalCache.getPassword(), LocalCache.getDuration(), LocalCache.getStorageFolder(), deviceId, LocalCache.getTouchWaitingDuration(), RKUtil.UPDATE_FLAG);
            RKUtil.uploadDeviceInfo(this, userInfoModel);
            MyWorkerManager.getInstance().oneTimeSendMessage();
        }
        finish();
    }

    public void listAllFolders(){
        StorageManager.getInstance(this).getFolders().addOnSuccessListener(new OnSuccessListener<ListResult>() {
            @Override
            public void onSuccess(ListResult listResult) {
                DebugLog.console("[ChangeStorageFolderScreen] inside onSuccess() ");
                List<StorageReference> sfolders = listResult.getPrefixes();
                for (StorageReference folder : sfolders) {
                    DebugLog.console("[ChangeStorageFolderScreen] inside onSuccess() "+folder.getName());
                    folders.add(folder.getName());
                }
                adapter = new StorageFolderRecyclerViewAdapter(folders, new StorageFolderRecyclerViewAdapter.CheckBoxListener() {
                    @Override
                    public void onChecked(int position,boolean isChecked) {
                        DebugLog.console("[ChangeStorageFolderScreen] inside onChecked() "+position+" isChecked : "+isChecked);

                            if(recyclerView.isComputingLayout()) {
//                            while (recyclerView.isComputingLayout()){
//                                if(!recyclerView.isComputingLayout()) {
//                                    runOnUiThread(() -> {
//                                        adapter.notifyDataSetChanged();
//                                        });
//                                    break;
//                                }
//                            }
                            }else{
                                runOnUiThread(() -> {
                                    adapter.notifyDataSetChanged();
                                });
                            }
                        if(isChecked)
                            checkBoxPosition = position;
                    }
                });
                recyclerView.setAdapter(adapter);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                DebugLog.console("[ChangeStorageFolderScreen] inside onFailure() "+e.toString());
            }
        });
    }
}